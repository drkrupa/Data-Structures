/**
 * COMP 410
 *See inline comment descriptions for methods not described in interface.
 *
*/
package LinkedList_A1;

public class LinkedListImpl implements LIST_Interface {
	Node sentinel; // this will be the entry point to your linked list (the head)
	private int size = 0;

	public LinkedListImpl() {// this constructor is needed for testing purposes. Please don't modify!
		sentinel = new Node(0); // Note that the root's data is not a true part of your data set!
		sentinel.next = sentinel;
		sentinel.prev = sentinel;
	}

	// implement all methods in interface, and include the getRoot method we made
	// for testing purposes. Feel free to implement private helper methods!

	public Node getRoot() { // leave this method as is, used by the grader to grab your linkedList easily.
		return sentinel;
	}

	public boolean insert(double elt, int index) {
		if ((index > size) || (index < 0)) {
			return false;
		} else if (index == size) {
			
			Node new_node = new Node(elt);
			Node current = sentinel;
			
			new_node.prev = current.getPrev();
			current.prev = new_node;
			new_node.getPrev().next = new_node;
			new_node.next = current;
			
			size++;
			return true;
			
		} else if (index < size / 2) {

			Node new_node = new Node(elt);
			Node current = sentinel.getNext();
			for (int i = 0; i < index; i++) {
				current = current.getNext();
			}

			new_node.prev = current.getPrev();
			current.prev = new_node;
			new_node.getPrev().next = new_node;
			new_node.next = current;

			size++;
			return true; 
		} else {
			
			Node new_node = new Node(elt);
			Node current = sentinel.getPrev();
			for (int i = 0; i < size() - 1 - index; i++) {
				current = current.getPrev();
			}
			new_node.prev = current.getPrev();
			current.prev = new_node;
			new_node.getPrev().next = new_node;
			new_node.next = current;
			
			size++;
			return true;
		}

	}

	public boolean remove(int index) {
		if (index >= size || index < 0) {
			return false;
		} else if (index < size / 2) {

			Node current = sentinel.getNext();
			for (int i = 0; i < index; i++) {
				current = current.getNext();
			}
			
			current.getNext().prev = current.getPrev();
			current.getPrev().next = current.getNext();
			

			size--;
			return true; 
		} else {
			
			Node current = sentinel.getPrev();
			for (int i = 0; i < size() - 1 - index; i++) {
				current = current.getPrev();
			}
			
			current.getNext().prev = current.getPrev();
			current.getPrev().next = current.getNext();
			
			size--;
			return true;
		}
	}

	public double get(int index) {
		if (index >= size() || index < 0) {
			return Double.NaN;
		} else if (index < size / 2) {

			Node current = sentinel.getNext();
			for (int i = 0; i < index; i++) {
				current = current.getNext();
			}

			return current.getData();
		} else {
			
			Node current = sentinel.getPrev();
			for (int i = size() - 1; i > index; i--) {
				current = current.getPrev();
			}
			
			return current.getData();
		}
	}

	public int size() {
		return size;
	}

	public boolean isEmpty() {
		return (size == 0);
	}

	public void clear() {
		sentinel.next = sentinel;
		sentinel.prev = sentinel;
		
		size = 0;

	}
}