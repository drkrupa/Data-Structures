package SPLT_A4;
public class SPLT implements SPLT_Interface {
	private BST_Node root;
	private int size;

	public SPLT() {
		this.size = 0;
	}
	
	public SPLT(BST_Node root) {
		this.size = 1;
		this.root = root;
		
	}

	public BST_Node getRoot() { // please keep this in here! I need your root node to test your tree!
		return root;
	}

	@Override
	public void insert(String s) { // It was me
		// TODO Auto-generated method stub
		if (empty()) {
			root = new BST_Node(s);
			size += 1;
			return;
		}

		if (contains(s)) {
			return;
		} else {
			size += 1;
			splay(root.insertNode(s));
		}

	}

	@Override
	public void remove(String s) {
		if (contains(s)) {
			if (root.left == null && root.right == null) {
				root = null;
			} else if (root.left == null) {
				root = root.right;
				root.parent = null;
			} else if (root.right == null) {
				root = root.left;
				root.parent = null;
			} else {
				root.left.parent = null;
				root.right.parent = null;
				SPLT left = new SPLT(root.left);
				left.findMax();
				root.left.right = root.right;
				root.right.parent = root.left;
				root = root.left;
			}
			
			size--;
		}

	}

	@Override
	public String findMin() {
		if (!empty()) {
			BST_Node s = root.findMin();
			splay(s);
			return root.data;
		}
		return null;
	}

	@Override
	public String findMax() {
		if (!empty()) {
			BST_Node s = root.findMax();
			splay(s);
			return root.data;
		}
		return null;
	}

	@Override
	public boolean empty() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean contains(String s) {
		if (empty()) {
			return false;
		}
		
		splay(root.containsNode(s));
		return (root.data.equals(s));
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public int height() {
		// TODO Auto-generated method stub
		if (empty()) {
			return -1;
		} else {
			return root.getHeight();
		}
	}

	private void splay(BST_Node s) {
		while (s.parent != null) {
			BST_Node parent = s.parent;
			BST_Node g_parent = parent.parent;
			if (g_parent != null) {
				if (g_parent.right == parent && parent.right == s) {
					rotateRight(parent);
					rotateRight(s);
				} else if (g_parent.left == parent && parent.left == s) {
					rotateLeft(parent);
					rotateLeft(s);
				} else if (parent.left == s) {
					rotateLeft(s);
					rotateRight(s);
				} else {
					rotateRight(s);
					rotateLeft(s);
				}
			} else if (parent.right == s) {
				rotateRight(s);
			} else {
				rotateLeft(s);
			}
				

		}
		
		root = s;
	}

	private void rotateRight(BST_Node s) {
		BST_Node p = s.parent;
		if (s.left != null) {
			p.right = s.left;
			p.right.parent = p;
		} else {
			p.right = null;
		}
		s.left = p;
		s.parent = p.parent;
		p.parent = s;
		
		if (s.parent != null) {
			if (s.parent.left == p) {
				s.parent.left = s;
			} else {
				s.parent.right = s;
			}
		}
	}

	private void rotateLeft(BST_Node s) {
		BST_Node p = s.parent;
		if (s.right != null) {
			p.left = s.right;
			p.left.parent = p;
		} else {
			p.left = null;
		}
		s.right = p;
		s.parent = p.parent;
		p.parent = s;
		
		if (s.parent != null) {
			if (s.parent.left == p) {
				s.parent.left = s;
			} else {
				s.parent.right = s;
			}
		}

	}
	

}