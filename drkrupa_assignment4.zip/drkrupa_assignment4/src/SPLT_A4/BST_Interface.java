package SPLT_A4;
public interface BST_Interface {//It was me
	  public boolean insert(String s);
	  public boolean remove(String s);
	  public String findMin();
	  public String findMax();
	  public boolean empty();
	  public boolean contains(String s);
	  public int size();
	  public int height();
	  public BST_Node getRoot(); //DIO
}
