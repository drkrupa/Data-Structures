package BST_A2;

public class BST_Node {
  String data;
  BST_Node left;
  BST_Node right;
  BST_Node parent;
  
  BST_Node(String data){ this.data=data; }

  // --- used for testing  ----------------------------------------------
  //
  // leave these 3 methods in, as is

  public String getData(){ return data; }
  public BST_Node getLeft(){ return left; }
  public BST_Node getRight(){ return right; }

  // --- end used for testing -------------------------------------------

  
  // --- fill in these methods ------------------------------------------
  //
  // at the moment, they are stubs returning false 
  // or some appropriate "fake" value
  //
  // you make them work properly
  // add the meat of correct implementation logic to them

  // you MAY change the signatures if you wish...
  // make the take more or different parameters
  // have them return different types
  //
  // you may use recursive or iterative implementations


  public boolean containsNode(String s){
	  if (this.data.equals(s)) {
		  return true;
	  } else if (this.left == null && this.right == null) {
		  return false;		  
	  } else if (this.left == null) {
		  return this.right.containsNode(s);
	  } else if (this.right == null) {
		  return this.left.containsNode(s);
	  } else if (s.compareTo(this.data) < 0) {
		  return (this.left.containsNode(s));
	  } else {
		  return this.right.containsNode(s);
	  }
  }
  
  public boolean insertNode(String s){
	  if (s == null || this.data.equals(s)) {
		  return false;
	  } else if (s.compareTo(data) < 0 && this.left == null) {
		  this.left = new BST_Node(s);
		  this.left.parent = this;
		  return true;
	  } else if (s.compareTo(data) > 0 && this.right == null) {
		  this.right = new BST_Node(s);
		  this.right.parent = this;
		  return true;
	  } else if (s.compareTo(data) < 0) {
		  return this.left.insertNode(s);
	  } else {
		  return this.right.insertNode(s);
	  }
  }
  
  public boolean removeNode(String s){
	  if (this.data.equals(s)) {
		  if (this.right == null && this.left == null) {
			  if (this.parent.left == this) {
				  this.parent.left = null;
			  } else {
				  this.parent.right = null;
			  }
		  } else if (this.left == null) {
			  if (this.parent.left == this) {
				  this.parent.left = this.right;
			  } else {
				  this.parent.right = this.right;
			  }
			  this.right.parent = this.parent;
		  } else if (this.right == null) {
			  if (this.parent.right == this) {
				  this.parent.right = this.left;
			  } else {
				  this.parent.left = this.left;
			  }
			  this.left.parent = this.parent;
		  } else {
			  String new_data = this.left.findMax().data;
			  this.data = new_data;
			  this.left.removeNode(new_data);
		  }
		  return true;
	  } else if (this.right == null && this.left == null) {
		  return false;
	  } else if (s.compareTo(data) < 0) {
		  return this.left.removeNode(s);
	  } else {
		  return this.right.removeNode(s);
	  }
  }
  
  public BST_Node findMin(){
	  if (this.left == null) {
		  return this;
	  } else {
		  return this.left.findMin();
	  }
  }
  
  public BST_Node findMax(){
	  if (this.right == null) {
		  return this;
	  } else {
		  return this.right.findMax();
	  }
  }
  
  public int getHeight(){
	  if (this.left == null && this.right == null) {
		  return 0;
	  } else if (this.left == null) {
		  return 1 + this.right.getHeight();
	  } else if (this.right == null) {
		  return 1 + this.left.getHeight();
	  } else {
		  return 1 + Math.max(this.left.getHeight(), this.right.getHeight());
	  }
  }


  // --- end fill in these methods --------------------------------------


  // --------------------------------------------------------------------
  // you may add any other methods you want to get the job done
  // --------------------------------------------------------------------
  
  public String toString(){
    return "Data: "+this.data+", Left: "+((this.left!=null)?left.data:"null")
            +",Right: "+((this.right!=null)?right.data:"null");
  }
}