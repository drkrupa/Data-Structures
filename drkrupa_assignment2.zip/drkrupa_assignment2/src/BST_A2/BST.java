package BST_A2;

public class BST implements BST_Interface {
  public BST_Node root;
  int size;
  
  public BST(){ size=0; root=null; }
  
  @Override
  //used for testing, please leave as is
  public BST_Node getRoot(){ return root; }

@Override
public boolean insert(String s) {
	if (this.getRoot() == null) {
		this.root = new BST_Node(s);
		size++;
		return true;
	} else {
		boolean completed = this.getRoot().insertNode(s);
		if (completed) {
			size++;
		}
		return completed;
	}
}

@Override
public boolean remove(String s) {
	if (size == 0 || s == null) {
		return false;
	} else if (s.equals(root.data) && this.getRoot().left == null && this.getRoot().right == null) {
		root = null;
		size--;
		return true;
	} else if (s.equals(root.data) && this.getRoot().left == null) {
		root = root.right;
		size--;
		return true;
	} else if (s.equals(root.data) && this.getRoot().right == null) {
		root = root.left;
		size--;
		return true;
	} else {
		boolean completed = this.getRoot().removeNode(s);
		if (completed) {
			size--;
		}
		return completed;
	}
}

@Override
public String findMin() {
	if (size == 0) {
		return null;
	} else {
		return this.getRoot().findMin().data;
	}
}

@Override
public String findMax() {
	if (size == 0) {
		return null;
	} else {
		return this.getRoot().findMax().data;
	}
}

@Override
public boolean empty() {
	return size == 0;
}

@Override
public boolean contains(String s) {
	if (size == 0) {
		return false;
	} else {
		return this.getRoot().containsNode(s);
	}
}

@Override
public int size() {
	return size;
}

@Override
public int height() {
	if (size == 0) {
		return -1;
	} else {
		return this.getRoot().getHeight();
	}
}

}