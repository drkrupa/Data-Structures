package A5_Dijkstra;

import java.util.HashMap;

public class Vertex implements Comparable {
	private String label;
	private long id;
	public HashMap<String, Edge> edges;
	public long dist;
	
	public Vertex(String label, long id) {
		this.label = label;
		this.id = id;
		this.edges = new HashMap<String, Edge>();
		dist = Long.MAX_VALUE;
	}
	
	public String getLabel() {
		return label;
	}
	
	public long getID() {
		return id;
	}
	
	public boolean addEdge(long idNum, String dLabel, long weight, String eLabel) {
		if (edges.containsKey(dLabel)) {
			return false;
		} else {
			edges.put(dLabel, new Edge(label, dLabel, weight, eLabel, idNum));
			return true;
		}
	}
	
	public long delEdge(String dLabel) {
		if (!(edges.containsKey(dLabel))) {
			return -1;
		}
		long ret = -1;
		if (edges.containsKey(dLabel)) {
			ret = edges.get(dLabel).getID();
			edges.remove(dLabel);
			return ret;
		} else {
			return ret;
		}
	}

	@Override
	public int compareTo(Object o) {
		return (int) this.id - (int) ((Vertex) o).getID();
	}
}
