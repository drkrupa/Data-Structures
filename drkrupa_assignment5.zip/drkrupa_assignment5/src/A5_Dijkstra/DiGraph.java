package A5_Dijkstra;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.PriorityQueue;


public class DiGraph implements DiGraphInterface {
	private HashMap<String, Vertex> nodes;
	private ArrayList<Vertex> list_nodes;
	private HashSet<Long> nodeIDs;
	private HashSet<Long> edgeIDs;
	
	
	public DiGraph() {
		nodes = new HashMap<String, Vertex>();
		nodeIDs = new HashSet<Long>();
		edgeIDs = new HashSet<Long>();
		list_nodes = new ArrayList<Vertex>();
	}
	
	

	@Override
	public boolean addNode(long idNum, String label) {
		if (idNum < 0 || nodes.containsKey(label) || nodeIDs.contains(idNum)) {
			return false;
		} else {
			Vertex n = new Vertex(label, idNum);
			nodes.put(label, n);
			list_nodes.add(n);
			nodeIDs.add(idNum);
			return true;
		}
	}

	@Override
	public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {
		if (idNum < 0 || edgeIDs.contains(idNum)) {
			return false;
		} else if (nodes.containsKey(sLabel) && nodes.containsKey(dLabel)
				&& nodes.get(sLabel).addEdge(idNum, dLabel, weight, eLabel)) {
			edgeIDs.add(idNum);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean delNode(String label) {
		if (nodes.containsKey(label)) {
			Vertex rem = nodes.get(label);
			long id = rem.getID();
			list_nodes.remove(rem);
			nodes.remove(label);
			nodeIDs.remove(id);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean delEdge(String sLabel, String dLabel) {
		if (!(nodes.containsKey(sLabel) && nodes.containsKey(dLabel))) { 
			return false;
		}
		long id = nodes.get(sLabel).delEdge(dLabel);
		if (id < 0) {
			return false;
		} else {
			edgeIDs.remove(id);
			return true;
		}
	}

	@Override
	public long numNodes() {
		return nodes.size();
	}

	@Override
	public long numEdges() {
		return edgeIDs.size();
	}



	@Override
	public ShortestPathInfo[] shortestPath(String label) {
		PriorityQueue<Vertex> q = new PriorityQueue<Vertex>();
		Iterator<Entry<String, Vertex>> it = nodes.entrySet().iterator();
		
		while (it.hasNext()) {
			Entry<String, Vertex> pair = it.next();
			pair.getValue().dist = Long.MAX_VALUE;
		}
		
		Vertex start = nodes.get(label);
		start.dist = 0;
		q.add(start);
		
		while (!q.isEmpty()) {
			Vertex v = q.remove();
			
			Iterator<Entry<String, Edge>> path = v.edges.entrySet().iterator();
			while (path.hasNext()) {
				Edge e = path.next().getValue();
				Vertex next = nodes.get(e.getEnd());
				if (next.dist > v.dist + e.getWeight()) {
					next.dist = v.dist + e.getWeight();
					q.add(next);
				}
				
			}
		}
		
		ShortestPathInfo[] s = new ShortestPathInfo[(int) numNodes()];
		
		for (int i = 0; i < numNodes(); i++) {
			Vertex v = list_nodes.get(i);
			ShortestPathInfo in;
			if (v.dist == Long.MAX_VALUE) {
				in = new ShortestPathInfo(v.getLabel(), -1);
			} else {
				in = new ShortestPathInfo(v.getLabel(), v.dist);
			}
			s[i] = in;
		}
		
		return s;
		
	}

}
