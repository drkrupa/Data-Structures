package A5_Dijkstra;

public class Edge {
	private long id;
	private String start;
	private String end;
	private String label;
	private long weight;
	
	public Edge(String start, String end, long id) {
		this.start = start;
		this.end = end;
		this.weight = 1;
		this.id = id;
	} 
	
	public Edge(String start, String end, long weight, long id) {
		this(start, end, id);
		this.weight = weight;
	}
	
	public Edge(String start, String end, String label, long id) {
		this(start, end, id);
		this.label = label;
	}
	
	public Edge(String start, String end, long weight, String label, long id) {
		this(start, end, weight, id);
		this.label = label;
	}
	
	public String getStart() {
		return start;
	}
	
	public String getEnd() {
		return end;
	}
	
	public String getLabel() {
		return label;
	}
	
	public long getWeight() {
		return weight;
	}
	
	public long getID() {
		return id;
	}

}
