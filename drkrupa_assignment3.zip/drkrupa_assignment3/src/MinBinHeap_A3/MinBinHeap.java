package MinBinHeap_A3;

public class MinBinHeap implements Heap_Interface {
	private EntryPair[] array; // load this array
	private int size;
	private static final int arraySize = 10000; // Everything in the array will initially
												// be null. This is ok! Just build out
												// from array[1]

	public MinBinHeap() {
		this.array = new EntryPair[arraySize];
		array[0] = new EntryPair(null, -100000); // 0th will be unused for simplicity
		size = 0; // of child/parent computations...
					// the book/animation page both do this.
	}

	// Please do not remove or modify this method! Used to test your entire Heap.
	@Override
	public EntryPair[] getHeap() {
		return this.array;
	}

	@Override
	public void insert(EntryPair entry) {
		if (size == 0) {
			array[1] = entry;
			size++;
		} else {
			int index = size + 1;
			bubbleUp(index, entry);
			size++;
		}

	}

	@Override
	public void delMin() {
		if (size == 0) {
			return;
		} else {
			array[1] = array[size];
			array[size] = null;
			size--;
			bubbleDown(1);

		}

	}

	@Override
	public EntryPair getMin() {
		return array[1];
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public void build(EntryPair[] entries) {
		for (int i = 1; i < entries.length + 1; i++) {
			array[i] = entries[i - 1];
		}
		size = entries.length;
		for (int i = size / 2; i > 0; i--) {
			bubbleDown(i);
		}

	}

	private void bubbleUp(int index, EntryPair entry) {
		if (entry.getPriority() > array[index / 2].getPriority()) {
			array[index] = entry;
			return;
		} else {
			array[index] = array[index / 2];
			bubbleUp(index / 2, entry);
		}
	}

	private void bubbleDown(int index) {
		int child = index * 2;
		
		
		while (child <= size) {
			if (child < size && array[child + 1].getPriority() < array[child].getPriority()) {
				child++;
			}
			if (array[child].getPriority() < array[index].getPriority()) {
				EntryPair temp = array[index];
				array[index] = array[child];
				array[child] = temp;
			}
			
			index = child;
			child *= 2;
		}
	}
}